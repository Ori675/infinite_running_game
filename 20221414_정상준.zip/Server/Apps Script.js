function doPost(e) {
    try {
        const data = JSON.parse(e.postData.contents);
        const sheet = SpreadsheetApp.openById('1q1I6l4cAA3JOOf2WFL2O5SZxqsE_tOFb1MKBnAWiIMU').getSheetByName('Sheet1');
        
        sheet.appendRow([
            data.eventId, 
            data.date, 
            data.time, 
            data.id, 
            data.password, 
            data.eventType, 
            data.comment
        ]);

        return ContentService.createTextOutput(JSON.stringify({ status 'success' }))
            .setMimeType(ContentService.MimeType.JSON)
            .setHeader('Access-Control-Allow-Origin', '')
            .setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS')
            .setHeader('Access-Control-Allow-Headers', 'Content-Type');
    } catch (error) {
        Logger.log('Error ' + error.message);
        return ContentService.createTextOutput(JSON.stringify({ status 'error', message error.message }))
            .setMimeType(ContentService.MimeType.JSON);
    }
}